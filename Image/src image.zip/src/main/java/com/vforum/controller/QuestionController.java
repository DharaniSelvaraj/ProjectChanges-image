package com.vforum.controller;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Questions;
import com.vforum.service.QuestionService;
@Controller
public class QuestionController {
	
	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	QuestionService questionService;
	
	@RequestMapping(value="/addQuestion", method = RequestMethod.GET)    
    public ModelAndView addQuestion()
	{ 
		ModelAndView model=new ModelAndView();
//    	Questions question=new Questions();
//    	long milli=System.currentTimeMillis();
//		Date currentDate=new Date(milli);
////    	question.setDate(currentDate);
//    	model.addObject("question", question);
        model.setViewName("Question");
        return model;
	} 
 
	@RequestMapping(value="/addQuestionProcess", method = RequestMethod.POST)    
    public ModelAndView addQuestionProcess(@RequestParam("questionImage") MultipartFile photo,@RequestParam("questionDescription") String questionDescription) throws SerialException, SQLException, IOException
	{   
		ModelAndView model=new ModelAndView();
		Questions question=new Questions();
		question.setQuestionDescription(questionDescription);
		long milli=System.currentTimeMillis();
		Date currentDate=new Date(milli);
		question.setDate(currentDate);
		System.out.println(questionDescription);
		System.out.println(photo.getName());
		System.out.println(photo.getContentType());
		question.setPhotoName(photo.getOriginalFilename());
		question.setPhotoContentType(photo.getContentType());
		byte[] photoBytes = photo.getBytes();
		Blob blob = new SerialBlob(photoBytes);
		question.setQuestionImage(blob);
		//try {
			//byte[] photoBytes = photo.getBytes();
			//			Blob blob = null;
//			try {
//				blob = new SerialBlob(photoBytes);
//			} catch (SerialException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			//question.setQuestionImage(blob);
			//question.setQuestionImage(photoBytes);
			questionService.save(question);
			List<Questions> list=questionService.list();
			model.addObject("list", list);
			model.setViewName("welcome");
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		

		return model;
	} 
	
	
	@RequestMapping(value="/getPhoto/{id}", method = RequestMethod.GET)    
    public void getPhoto(HttpServletResponse response, @PathVariable("id") int id) throws SQLException, IOException
	{ 
		response.setContentType("image/jpeg");
		Blob ph =questionService.getPhoto(id);
		byte[] bytes = ph.getBytes(1, (int) ph.length());
		InputStream inputStream = new ByteArrayInputStream(bytes);
		IOUtils.copy(inputStream, response.getOutputStream());
	} 
	
    	
}
