package com.vforum.service;

import java.sql.Blob;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vforum.dao.QuestionDao;
import com.vforum.model.Questions;
@Service
public class QuestionServiceImpl implements QuestionService {

	@Autowired
	QuestionDao questionDao;
	
	@Transactional
	public void save(Questions question) {
		questionDao.save(question);
	}
	
	public void setQuestionDao(QuestionDao questionDao) {
		this.questionDao = questionDao;
	}

	@Override
	@Transactional
	public List<Questions> list() {
		return questionDao.list();
	}

	@Override
	@Transactional
	public Blob getPhoto(int questionId) {
		
		return questionDao.getPhoto(questionId);
	}

}
