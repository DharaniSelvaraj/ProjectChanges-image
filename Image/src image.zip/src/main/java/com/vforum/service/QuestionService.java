
package com.vforum.service;

import java.sql.Blob;
import java.util.List;



import com.vforum.model.Questions;

public interface QuestionService {
	public void save(Questions question) ;
	
	public List<Questions> list();
	
	public Blob getPhoto(int questionId);
}
