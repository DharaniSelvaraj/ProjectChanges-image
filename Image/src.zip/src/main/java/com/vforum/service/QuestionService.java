
package com.vforum.service;

import com.vforum.model.Questions;

public interface QuestionService {
	public void save(Questions question) ;

}
