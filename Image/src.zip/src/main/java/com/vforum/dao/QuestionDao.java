package com.vforum.dao;

import com.vforum.model.Questions;

public interface QuestionDao {
	public void save(Questions question) ;
}
