package com.vforum.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vforum.model.Questions;

@Repository
public class QuestionDaoImpl implements QuestionDao{
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void save(Questions question) {
		sessionFactory.getCurrentSession().save(question);
	}

}


	