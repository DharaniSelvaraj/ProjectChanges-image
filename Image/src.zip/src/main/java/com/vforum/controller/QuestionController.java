package com.vforum.controller;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Date;
import java.sql.SQLException;

import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Questions;
import com.vforum.service.QuestionService;
@Controller
public class QuestionController {
	
	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	QuestionService questionService;
	
	@RequestMapping(value="/addQuestion", method = RequestMethod.GET)    
    public ModelAndView addQuestion()
	{ 
		ModelAndView model=new ModelAndView();
    	Questions question=new Questions();
    	long milli=System.currentTimeMillis();
		Date currentDate=new Date(milli);
    	question.setDate(currentDate);
        model.setViewName("Question");
        return model;
	} 
 
	@RequestMapping(value="/addQuestionProcess", method = RequestMethod.POST)    
    public ModelAndView addQuestionProcess(@RequestParam("photo") MultipartFile photo,@ModelAttribute("question") Questions question)
	{   
		ModelAndView model=new ModelAndView();
		System.out.println(question.getQuestionDescription());
		System.out.println(question.getQuestionId());
		System.out.println(photo.getName());
		System.out.println(photo.getContentType());
		try {
			byte[] photoBytes = photo.getBytes();
			question.setPhotoName(photo.getOriginalFilename());
			question.setPhotoContentType(photo.getContentType());
			Blob blob = null;
			try {
				blob = new SerialBlob(photoBytes);
			} catch (SerialException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			question.setQuestionImage(blob);
			questionService.save(question);
			model.setViewName("welcome");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

		return model;
	} 
    	
   
 
 

}
