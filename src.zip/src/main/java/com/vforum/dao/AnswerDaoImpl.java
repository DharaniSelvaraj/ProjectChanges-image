package com.vforum.dao;

import java.util.List;

import org.apache.log4j.Logger;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vforum.model.Answers;

@Repository
public class AnswerDaoImpl implements AnswerDao {
	Logger log = Logger.getLogger(this.getClass());
	 @Autowired
	    private SessionFactory sessionFactory;
	 
	   
	
	public void addAnswer(Answers answer) {
		try {
			log.info("This is AnswerDaoImpl addAnswer method");
		    sessionFactory.getCurrentSession().save(answer);
		} catch (Exception e) {
			log.error("Error is in AnswerDaoImpl addAnswer method" + e);
		}

	}

	public Answers getAnswer(int answerId) {
		Answers answer=null;
		try {
			log.info("This is AnswerDaoImpl getAnswer method");
	        answer= (Answers) sessionFactory.getCurrentSession().get(
	             Answers.class, answerId);
		} catch (Exception e) {
			log.error("Error is in AnswerDaoImpl getAnswer method" + e);
		}
		return answer;
	}

	public void editAnswer(Answers answer) {
		try {
			log.info("This is AnswerDaoImpl editAnswer method");
		    sessionFactory.getCurrentSession().update(answer);
		} catch (Exception e) {
			log.error("Error is in AnswerDaoImpl editAnswer method" + e);
		}
	
	}
	public void deleteAnswer(Answers answer) {
		try {
			log.info("This is AnswerDaoImpl deleteAnswer method");
	        sessionFactory.getCurrentSession().delete(answer);
		} catch (Exception e) {
			log.error("Error is in AnswerDaoImpl deleteAnswer method" + e);
		}
			
	}
	
	@SuppressWarnings("unchecked")
	public List<Answers> getAllAnswers() {
		List<Answers> allAnswer=null;
		try {
			log.info("This is AnswerDaoImpl getAllAnswers method");
	        String hql="from Answers order by answerId desc";
		    Query query=sessionFactory.getCurrentSession().createQuery(hql);
		    allAnswer=query.list();
		
		} catch (Exception e) {
			log.error("Error is in AnswerDaoImpl getAllAnswers method" + e);
		}
		return allAnswer;	}

	

	@SuppressWarnings("unchecked")
	public List<Answers> getAnswersByQuestionId(int questionId) {
		List<Answers> answerList=null;
		try {
			log.info("This isAnswerDaoImpl getAnswersByQuestionId method");
	        String hql="from Answers where questionId="+questionId;
			Query query=sessionFactory.getCurrentSession().createQuery(hql);
			answerList=query.list();
		} catch (Exception e) {
			log.error("Error is in AnswerDaoImpl getAnswersByQuestionId method " + e);
		}
		return answerList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Answers> getAnswersByEmployee(int employeeId) {
		List<Answers> answerList=null;
		try {
			log.info("This isAnswerDaoImpl getAnswersByEmployee method");
	        String hql="from Answers where employeeId="+employeeId;
			Query query=sessionFactory.getCurrentSession().createQuery(hql);
			answerList=query.list();
		} catch (Exception e) {
			log.error("Error is in AnswerDaoImpl getAnswersByEmployee method " + e);
		}
		return answerList;
	}

}