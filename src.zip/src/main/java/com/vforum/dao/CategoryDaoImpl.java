package com.vforum.dao;

import org.apache.log4j.Logger;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vforum.model.Category;

@Repository
public class CategoryDaoImpl implements CategoryDao {
	Logger log = Logger.getLogger(this.getClass());
	 @Autowired
	    private SessionFactory sessionFactory;
	

	public Category getCategoryById(int categoryId) {
		Category category=null;
		try {
			log.info("This is CategoryDaoImpl getCategoryById dao method Log ");
		    category= (Category) sessionFactory.getCurrentSession().get(
	                Category.class, categoryId);
	
		} catch (Exception e) {
			log.error("Error is in CategoryDaoImpl getCategoryById dao method Log  " + e);
		}
		return category;
}
}