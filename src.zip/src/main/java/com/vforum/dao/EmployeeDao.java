package com.vforum.dao;


import java.util.List;

import com.vforum.model.Employee;
	public interface  EmployeeDao {
	 
	    public void addEmployee(Employee employee);
		 
	    public Employee getEmployee(int employeeid);
	    
	    public List<Employee> getAllEmployees();
	   
	}