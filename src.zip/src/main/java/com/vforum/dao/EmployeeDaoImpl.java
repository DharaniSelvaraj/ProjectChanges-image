package com.vforum.dao;

	import java.util.List;

import org.apache.log4j.Logger;

import org.hibernate.SessionFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;

import com.vforum.model.Employee;
	 
	@Repository
	public class EmployeeDaoImpl implements EmployeeDao {
		Logger log = Logger.getLogger(this.getClass());
	 
	    @Autowired
	    private SessionFactory sessionFactory;
	 
	    public void addEmployee(Employee employee) {
	    	try {
				log.info("This is addEmployee Page Log");
	            sessionFactory.getCurrentSession().saveOrUpdate(employee);
			} catch (Exception e) {
				log.error("Error is in addEmployee   dao method Log  " + e);
			}
	 
	    }
	 
	    @SuppressWarnings("unchecked")
	    public List<Employee> getAllEmployees() {
	    	 List<Employee> employeeList=null;
	    	try {
				log.info("This is getAllEmployees Page Log");
				employeeList= sessionFactory.getCurrentSession().createQuery("from Employee")
	                .list();
			} catch (Exception e) {
				log.error("Error is in getAllEmployees   dao method Log  " + e);
			}
	    	return employeeList;
	    }

	 
	    public Employee getEmployee(int empid) {
	    	Employee employee=null;
	    	try {
				log.info("This is getEmployee Page Log");
				employee= (Employee) sessionFactory.getCurrentSession().get(
	                Employee.class, empid);
			} catch (Exception e) {
				log.error("Error is in getEmployee   dao method Log  " + e);
			}
		return employee;
	    }


	 
	}	
	
	