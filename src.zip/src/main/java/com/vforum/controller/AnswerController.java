package com.vforum.controller;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.vforum.model.Answers;
import com.vforum.model.Employee;
import com.vforum.model.Questions;
import com.vforum.service.AnswerService;
import com.vforum.service.EmployeeService;
import com.vforum.service.QuestionService;

@Controller
public class AnswerController {

	
		Logger log = Logger.getLogger(this.getClass());
		@Autowired
	    private EmployeeService employeeService;
	    @Autowired
	    private AnswerService answerService;
	    @Autowired
	    private QuestionService questionService;
	    
	    @RequestMapping(value ="/addAnswer", method = RequestMethod.GET)    
	    public ModelAndView addAnswer(ModelAndView model,HttpSession session,@RequestParam(value="qid") Integer questionId){ 
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is in AnswerController postAnswer method ");
			    	Answers answer=new Answers();
			    	
			    	long milli=System.currentTimeMillis();
					Date currentDate=new Date(milli);
			    	answer.setDate(currentDate);
			    	Questions question=questionService.getQuestion(questionId);
			    	answer.setQuestion(question);
			    	Employee employee=employeeService.getEmployee(employeeId);
			        answer.setEmployee(employee);
			        model.addObject("employee", employee);
			    	model.addObject("answer", answer);
			    	model.addObject("question", question);
			        model.setViewName("Answer");
	    		    				}
		 		} catch (Exception e) {
				log.error("Error is in AnswerController postAnswer method  " + e);
		 		}
	    	return model;
	    }
	 
	    @RequestMapping(value = "/addAnswerProcess", method = RequestMethod.POST)
	    public String addAnswerProcess(@ModelAttribute Answers answer,HttpSession session) {
	    	String url=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					
					log.info("This is AnswerController addAnswer method ");
			    	answerService.addAnswer(answer);
			    	url="redirect:homePage";
	    		}
	    	} catch (Exception e) {
				log.error("Error is in AnswerController addAnswer method " + e);
			}
	    	return url;
	       
	    }
	    @RequestMapping(value = "/editAnswer", method = RequestMethod.GET)
	    public ModelAndView editAnswer(@RequestParam(value="aid") Integer answerId,HttpSession session) {
	    	ModelAndView model =null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController editAnswer method ");
			        Answers answer = answerService.getAnswer(answerId);
			        model = new ModelAndView();
			        model.addObject("answer", answer);
			        model.setViewName("editAnswer");
	    		}
		        
	    	} catch (Exception e) {
				log.error("Error is in AnswerController editAnswer method " + e);
			}
	    	return model;
	    }
	   
	    @RequestMapping(value = "/editAnswerProcess", method = RequestMethod.POST)
	    public String editAnswerProcess(@ModelAttribute Answers answer,HttpSession session) {
	    	
	    	
	    	String url=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
	    			
					log.info("This is AnswerController postAnswer method ");
					answerService.editAnswer(answer);
					url="redirect:homePage";
	    		}
	       
	    	} catch (Exception e) {
				log.error("Error is in AnswerController postAnswer method " + e);
			}
	    	 return url;
	    }
	    @RequestMapping(value = "/deleteAnswer", method = RequestMethod.GET)
	    public String deleteAnswer(@RequestParam(value="aid") Integer answerId,HttpSession session) {
	      
	    	String url=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController postAnswer method ");
			        Answers answer = answerService.getAnswer(answerId);
			        answerService.deleteAnswer(answer);
			        url="redirect:homePage";
	    		}
			        
	    	} catch (Exception e) {
				log.error("Error is in AnswerController postAnswer method " + e);
			}
	    	return url;
	    }
	    @RequestMapping(value = "/viewMyAnswer", method = RequestMethod.GET)
	    public ModelAndView viewMyAnswer(HttpSession session) {
	    	ModelAndView model=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		if(employeeId!=null) {
					log.info("This is AnswerController viewMyAnswer method ");
					
				    model = new ModelAndView();
				    Employee employee=employeeService.getEmployee(employeeId);
				    model.addObject("employee",employee);
				    List<Questions> allQuestions=questionService.getAllQuestions();
			        model.addObject("allQuestions",allQuestions);
			     	List<Answers> allAnswers=answerService.getAnswersByEmployee(employeeId);
			        model.addObject("allAnswers",allAnswers);
			        model.setViewName("MyAnswers");
	    							}
	    	} catch (Exception e) {
				log.error("Error is in AnswerController viewMyAnswer method " + e);
			}
	        return model;
	    }
	    
	    @RequestMapping(value = "/viewAnswers", method = RequestMethod.GET)
	    public ModelAndView viewAnswers(HttpSession session,@RequestParam(value="qid") Integer questionId) {
	    	ModelAndView model=null;
	    	try {
	    		Integer employeeId=(Integer) session.getAttribute("employeeId");
	    		
	    		if(employeeId!=null) {
					log.info("This is AnswerController viewAnswer method ");
				    model = new ModelAndView();
				    Employee employee=employeeService.getEmployee(employeeId);
				    model.addObject("employee",employee);
				    Questions question=questionService.getQuestion(questionId);
				    model.addObject("question",question);
			     	List<Answers> allAnswers=answerService.getAnswersByQuestionId(questionId);
			        model.addObject("allAnswers",allAnswers);
			        model.setViewName("ViewAnswers");
	    							}
	    	} catch (Exception e) {
				log.error("Error is in AnswerController viewAnswer method " + e);
			}
	        return model;
	    }

}